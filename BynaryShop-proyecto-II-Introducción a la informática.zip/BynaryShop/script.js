document.addEventListener('DOMContentLoaded', function() {
  // Variables globales
  let users = [
    { username: 'seller456', password: 'Intro123', role: 'comprador' },
    { username: 'dancabello', password: 'J5*asdRD.s', role: 'vendedor' },
    { username: 'root', password: 'dochouse', role: 'admin' }
  ];

  let products = [
    { name: 'Procesador Intel i7', category: 'procesadores', image: 'imagenes/procesador.jpg', description: 'Procesador de alto rendimiento', price: '$300' },
    { name: 'Tarjeta Gráfica RTX 3080', category: 'tarjetas-graficas', image: 'imagenes/tarjeta-grafica.jpg', description: 'Tarjeta gráfica de última generación', price: '$700' },
    { name: 'Memoria RAM 16GB', category: 'memorias-ram', image: 'imagenes/memoria-ram.jpg', description: 'Memoria RAM de alta velocidad', price: '$100' },
    { name: 'Disco Duro 1TB', category: 'discos-duros', image: 'imagenes/disco-duro.jpg', description: 'Disco duro con gran capacidad', price: '$50' },
    { name: 'Fuente de Poder 750W', category: 'fuentes-de-poder', image: 'imagenes/fuente-de-poder.jpg', description: 'Fuente de poder eficiente', price: '$80' }
  ];

  let cart = [];
  let selectedRole = ''; // Se almacenará el rol seleccionado

  // Función de login
  function login(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('error-message');

    const user = users.find(user => user.username === username && user.password === password);

    // Si se ha seleccionado un rol, verificar que el rol del usuario concuerde
    if (selectedRole && user && user.role !== selectedRole) {
      errorMessage.textContent = 'El rol del usuario no coincide con el rol seleccionado.';
      errorMessage.classList.remove('hidden');
      return;
    }

    if (user) {
      alert(`Bienvenido, ${user.role}!`);
      document.getElementById('login-form').classList.add('hidden');
      document.getElementById('categories').classList.remove('hidden');
      errorMessage.classList.add('hidden');

      if (user.role === 'admin') {
        document.getElementById('admin-options').classList.remove('hidden');
      } else if (user.role === 'vendedor') {
        document.getElementById('vendor-options').classList.remove('hidden');
      } else {
        document.getElementById('product-list').classList.remove('hidden');
        document.getElementById('cart').classList.remove('hidden');
        filterProducts('');
      }
    } else {
      errorMessage.textContent = 'Usuario o contraseña incorrectos';
      errorMessage.classList.remove('hidden');
    }
  }

  // Función de registro 
  function register(event) {
    event.preventDefault();
    const newUsername = document.getElementById('new-username').value;
    const newPassword = document.getElementById('new-password').value;
    users.push({ username: newUsername, password: newPassword, role: 'comprador' });
    alert('Registro exitoso. Ahora inicie sesión.');
    // Ocultar formulario de registro
    document.getElementById('register-form').classList.add('hidden');
  }

  // Funciones para mostrar/ocultar Registro y Selección de Roles
  function toggleRegister() {
    document.getElementById('register-form').classList.toggle('hidden');
  }

  function toggleRole() {
    document.getElementById('role-selection').classList.toggle('hidden');
  }

  // Función para seleccionar rol 
  function selectRole(role) {
    selectedRole = role;
    alert(`Rol seleccionado: ${role}`);
    // Actualizar la información del rol en el login
    document.getElementById('selected-role-text').textContent = role;
    document.getElementById('selected-role-info').classList.remove('hidden');
    // Ocultar la sección de selección de rol
    document.getElementById('role-selection').classList.add('hidden');
  }

  // Función para filtrar productos
  function filterProducts(category) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    products.filter(product => category === '' || product.category === category)
      .forEach(product => {
        const productDiv = document.createElement('div');
        productDiv.classList.add('product');
        productDiv.innerHTML = `
          <img src="${product.image}" alt="${product.name}">
          <h2>${product.name}</h2>
          <p>${product.description}</p>
          <p>${product.price}</p>
          <button onclick="addToCart('${product.name}')">Añadir al Carrito</button>
        `;
        productList.appendChild(productDiv);
      });
  }

  // Función para agregar producto zona del vendedor)
  function addProduct(event) {
    event.preventDefault();
    const name = document.getElementById('product-name').value;
    const description = document.getElementById('product-description').value;
    const image = document.getElementById('product-image').value;
    const price = document.getElementById('product-price').value;
    products.push({ name, description, image, price, category: 'otros' });
    alert('Producto añadido exitosamente');
    filterProducts('');
  }

  // Funciones del carrito
  function addToCart(productName) {
    const product = products.find(product => product.name === productName);
    if (product) {
      cart.push(product);
      updateCart();
      alert(`Añadido al carrito: ${product.name}`);
    } else {
      alert('Producto no encontrado');
    }
  }

  function updateCart() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach((product, index) => {
      const cartItem = document.createElement('li');
      cartItem.innerHTML = `
        <img src="${product.image}" alt="${product.name}" style="width:50px; height:auto;">
        ${product.name} <button onclick="removeFromCart(${index})">Eliminar</button>
      `;
      cartItems.appendChild(cartItem);
      total += parseFloat(product.price.replace('$',''));
    });
    document.getElementById('cart-total').textContent = `$${total}`;
  }

  function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
  }

  function checkout() {
    if (cart.length === 0) {
      alert('El carrito está vacío');
      return;
    }
    alert('Compra realizada exitosamente');
    cart = [];
    updateCart();
    document.getElementById('cart').classList.add('animation');
  }

  // Funciones del área administrador
  function showAdminOptions() {
    document.getElementById('admin-panel').classList.toggle('hidden');
  }

  function deleteProduct() {
    const productName = document.getElementById('product-to-delete').value;
    products = products.filter(product => product.name !== productName);
    alert('Producto eliminado exitosamente');
    filterProducts('');
  }

  function deleteUser() {
    const username = document.getElementById('user-to-delete').value;
    const userIndex = users.findIndex(user => user.username === username);
    if (userIndex !== -1) {
      users.splice(userIndex, 1);
      alert('Usuario eliminado exitosamente');
    } else {
      alert('Usuario no encontrado');
    }
  }

  // Asignar eventos
  document.getElementById('login-form').onsubmit = login;
  document.getElementById('categories').addEventListener('click', (event) => {
    if (event.target.tagName === 'BUTTON') {
      const category = event.target.getAttribute('data-category');
      filterProducts(category);
    }
  });
  const vendorForm = document.querySelector('#vendor-options form');
  if (vendorForm) {
    vendorForm.onsubmit = addProduct;
  }
  const checkoutBtn = document.getElementById('cart').querySelector('button');
  if (checkoutBtn) {
    checkoutBtn.onclick = checkout;
  }
  const adminBtn = document.getElementById('admin-options').querySelector('button');
  if (adminBtn) {
    adminBtn.onclick = showAdminOptions;
  }

  // Estas globales hacen algunas funciones para que puedan ser llamadas desde los atributos inline
  window.addToCart = addToCart;
  window.removeFromCart = removeFromCart;
  window.checkout = checkout;
  window.filterProducts = filterProducts;
  window.addProduct = addProduct;
  window.showAdminOptions = showAdminOptions;
  window.deleteProduct = deleteProduct;
  window.deleteUser = deleteUser;
  window.login = login;
  window.register = register;
  window.toggleRegister = toggleRegister;
  window.toggleRole = toggleRole;
  window.enterAsRole = selectRole; // Usamos selectRole para asignar el rol seleccionado
});
